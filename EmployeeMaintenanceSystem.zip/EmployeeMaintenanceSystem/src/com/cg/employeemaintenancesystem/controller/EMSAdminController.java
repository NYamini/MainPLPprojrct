package com.cg.employeemaintenancesystem.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employeemaintenancesystem.entity.Employee;
import com.cg.employeemaintenancesystem.service.IEMSService;
import com.cg.employeemaintenancesystem.entity.LeaveHistory;

@Controller
public class EMSAdminController {
	@Autowired
	IEMSService empservice;
	
		
	@RequestMapping(value="AddEmployeePage")
	public ModelAndView addEmployee(@RequestParam String name,HttpServletRequest request,HttpServletResponse response,HttpSession session)
	{
		ModelAndView view = new ModelAndView();
		session=request.getSession(false);
		if (session!= null || null!=session.getAttribute("name")) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            response.setHeader("Pragma", "no-cache"); 
            response.setDateHeader("Expires", 0);
		
		Employee employee = new Employee();
		view.setViewName("AddEmployeePage");
		view.addObject("employee", employee);
		view.addObject("name",name);
		ArrayList<Integer> list = new ArrayList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		view.addObject("departmentList", list);
		ArrayList<String> gradeList = new ArrayList<>();
		gradeList.add("M1");
		gradeList.add("M2");
		gradeList.add("M3");
		gradeList.add("M4");
		gradeList.add("M5");
		gradeList.add("M6");
		gradeList.add("M7");
		view.addObject("gradeList", gradeList);
		}
		return view;
	}
	/****************************************************************************************************************************
	�- Method Name������: insertEmployeeDetails
	�- Input Parameters : Employee employee
	�- Return type������: ModelAndView
	�- Author�����������: Batch-01
	�- Creation Date��� : 21-07-2018
	�- Description������: Inserting the Employee details�into��the database.
	��****************************************************************************************************************************/ 

	@RequestMapping(value ="/insertDetails",method = RequestMethod.POST)
	public ModelAndView insertEmployeeDetails(@RequestParam String name,
			@ModelAttribute("employee") @Valid Employee employee,BindingResult bindingResult,HttpServletRequest request,HttpServletResponse response,HttpSession session) {
		ModelAndView view = new ModelAndView();
		session=request.getSession(false);
		if (session!= null || null!=session.getAttribute("name")) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
            response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
            response.setDateHeader("Expires", 0);
		view.addObject("name",name);
		try {
			if(bindingResult.hasErrors())
			{
				ArrayList<Integer> list = new ArrayList<>();
				list.add(1);
				list.add(2);
				list.add(3);
				list.add(4);
				view.addObject("departmentList", list);
				ArrayList<String> gradeList = new ArrayList<>();
				gradeList.add("M1");
				gradeList.add("M2");
				gradeList.add("M3");
				gradeList.add("M4");
				gradeList.add("M5");
				gradeList.add("M6");
				gradeList.add("M7");
				view.addObject("gradeList", gradeList);
				view.addObject("name",name);
				view.setViewName("AddEmployeePage");
				
			}
			else
			{
			String fd = employee.getEmployeeDOB();
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date date;
			date = sdf1.parse(fd);
			java.sql.Date sqlDateOfBirth = new java.sql.Date(date.getTime());
			employee.setDateOfBirth(sqlDateOfBirth);

			String td = employee.getEmployeeDOJ();
			date = sdf1.parse(td);
			java.sql.Date sqlDateOfJoin = new java.sql.Date(date.getTime());
			employee.setDateOfJoining(sqlDateOfJoin);
			String message = empservice.adminAddEmployee(employee);
			view.addObject("message", message);
			view.addObject("name",name);
			view.setViewName("Success");
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			ArrayList<Integer> list = new ArrayList<>();
			list.add(1);
			list.add(2);
			list.add(3);
			list.add(4);
			view.addObject("departmentList", list);
			ArrayList<String> gradeList = new ArrayList<>();
			gradeList.add("M1");
			gradeList.add("M2");
			gradeList.add("M3");
			gradeList.add("M4");
			gradeList.add("M5");
			gradeList.add("M6");
			gradeList.add("M7");
			view.addObject("gradeList", gradeList);
			view.addObject("message","please enter valid date pattern i.e dd/MM/yyyy !!!!");
			view.setViewName("AddEmployeePage");
		}
		}
		return view;
	}
	
	/****************************************************************************************************************************
	�- Method Name������: displayEmployeesDetails
	�- Input Parameters : NA
	�- Return type������: ModelAndView
	�- Author�����������: Batch-01
	�- Creation Date��� : 21-07-2018
	�- Description������: Displaying all Employee Details.
	��****************************************************************************************************************************/ 
	@RequestMapping(value="DisplayEmployeePage")
	public ModelAndView displayEmployeesDetails(HttpServletRequest request,HttpServletResponse response,HttpSession session) {
		ModelAndView view=new ModelAndView();
		session=request.getSession(false);
		if (session!= null || null!=session.getAttribute("name")) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
            response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
            response.setDateHeader("Expires", 0);
		view.setViewName("AllDetails");
		ArrayList<Employee> emplist=new ArrayList<>();
		emplist=empservice.adminDisplayAllEmployees();
		view.addObject("details", emplist);}
		return view;
	}
	
	@RequestMapping(value="ModifyEmployeePage")
	public ModelAndView verifyEmployeeId(HttpServletRequest request,HttpServletResponse response,HttpSession session) {
		ModelAndView view=new ModelAndView();
		session=request.getSession(false);
		if (session!= null || null!=session.getAttribute("name")) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
            response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
            response.setDateHeader("Expires", 0);
		Employee emp=new Employee();
		view.addObject("employee",emp);
		view.setViewName("ModifyEmployeePage");}
		
		return view;		
	}
	/****************************************************************************************************************************
	�- Method Name������: modifyEmployee
	�- Input Parameters : Employee employee
	�- Return type������: ModelAndView
	�- Author�����������: Batch-01
	�- Creation Date��� : 21-07-2018
	�- Description������: Fetching the Specified Employee details�from��the database.
	��****************************************************************************************************************************/ 
	
	@RequestMapping(value="modifySearch")
	public ModelAndView modifyEmployee(@ModelAttribute("employee") Employee employee,HttpServletRequest request,HttpServletResponse response,HttpSession session) {
		ModelAndView view=new ModelAndView();
		session=request.getSession(false);
		if (session!= null || null!=session.getAttribute("name")) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
            response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
            response.setDateHeader("Expires", 0);}
		Employee emp=new Employee();
		ArrayList<Integer> list = new ArrayList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		view.addObject("departmentList", list);
		ArrayList<String> gradeList = new ArrayList<>();
		gradeList.add("M1");
		gradeList.add("M2");
		gradeList.add("M3");
		gradeList.add("M4");
		gradeList.add("M5");
		gradeList.add("M6");
		gradeList.add("M7");
		view.addObject("gradeList", gradeList);
		view.addObject("employee",emp);
		ArrayList<Employee> empList=empservice.userIdSearchEmployee(employee.getEmployeeId());
		if(empList.isEmpty())
		{
			view.addObject("message","please enter valid employee id!!!!!!!");
			view.setViewName("ModifyEmployeePage");
		}
		else
		{
		
		view.addObject("e",empList);
		view.setViewName("Modify2");
		}
		return view;		
	}
	/****************************************************************************************************************************
	�- Method Name������: modifyEmployeeDetails
	�- Input Parameters : Employee employee
	�- Return type������: ModelAndView
	�- Author�����������: Batch-01
	�- Creation Date��� : 21-07-2018
	�- Description������: Modifying the Specified Employee details in the database.
	��****************************************************************************************************************************/ 
	@RequestMapping(value="/modify",method=RequestMethod.POST)
	public ModelAndView modifyEmployeeDetails(@ModelAttribute("employee") @Valid Employee employee,BindingResult bindingResult,HttpServletRequest request,HttpServletResponse response,HttpSession session){
		ModelAndView view=new ModelAndView();
		session=request.getSession(false);
		if (session!= null || null!=session.getAttribute("name")) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
            response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
            response.setDateHeader("Expires", 0);
		if(bindingResult.hasErrors())
		{
			view.setViewName("Modify2");
		}
		view.addObject("message",empservice.adminModifyEmployee(employee)+" Modified succesfully!!!");
		view.setViewName("Success");}
		return view;
	}
	
	/****************************************************************************************************************************
	�- Method Name������: displayAppliedLeaves
	�- Input Parameters : NA
	�- Return type������: ModelAndView
	�- Author�����������: Batch-01
	�- Creation Date��� : 21-07-2018
	�- Description������: Display all Applied Leaves.
	��****************************************************************************************************************************/ 
	@RequestMapping(value="/DisplayAppliedLeaves")
	public ModelAndView displayAppliedLeaves(HttpServletRequest request,HttpServletResponse response,HttpSession session){
		ModelAndView view=new ModelAndView();
		session=request.getSession(false);
		if (session!= null || null!=session.getAttribute("name")) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
            response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
            response.setDateHeader("Expires", 0);
		String userId=(String) session.getAttribute("userId");
		ArrayList<LeaveHistory> list=new ArrayList<>();
		list=empservice.adminDisplayLeaves(userId);
		if(list.isEmpty())
		{
			String message="You have no pending leaves to approve!!";
			view.addObject("message",message);
			view.setViewName("Success");
		}
		else{
		view.addObject("displayList",list);
		view.setViewName("Success");
		}
		}
		return view;	
	}
	/****************************************************************************************************************************
	�- Method Name������: statusUpdate
	�- Input Parameters : String decision,Integer leaveId,Integer leaveBalance,Integer noOfDaysApplied
	�- Return type������: ModelAndView
	�- Author�����������: Batch-01
	�- Creation Date��� : 21-07-2018
	�- Description������: Updating Leave Status.
	��****************************************************************************************************************************/ 
	@RequestMapping(value="/decision")
	public ModelAndView statusUpdate(@RequestParam("decision") String decision,@RequestParam("leaveId") Integer leaveId,@RequestParam("leaveBalance") Integer leaveBalance,@RequestParam("noOfDaysApplied") Integer noOfDaysApplied,HttpSession session,HttpServletRequest request,HttpServletResponse response){
		ModelAndView view=new ModelAndView();
		session=request.getSession(false);
		if (session!= null || null!=session.getAttribute("name")) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
            response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
            response.setDateHeader("Expires", 0);
		if(decision.equals("Approve"))
		{
			decision="approved";
		}
		else
		{
			decision="rejected";
		}
		Integer id=empservice.adminApproveLeave(leaveId, decision,leaveBalance,noOfDaysApplied);
		String userId=(String) session.getAttribute("userId");
		ArrayList<LeaveHistory> list=new ArrayList<>();
		list=empservice.adminDisplayLeaves(userId);
		if(list.isEmpty())
		{
			String message="You have no pending leave to approve!!";
			view.addObject("message",message);
			view.setViewName("Success");
		}
		else{
		view.addObject("displayList",list);
		view.setViewName("Success");
		}
		}
		return view;
	}
}
